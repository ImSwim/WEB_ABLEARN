export default [
    {id:1, img:'./images/car1.jpg'},
    {id:2, img:'./images/car2.jpg'},
    {id:3, img:'./images/car3.jpg'},
    {id:4, img:'./images/car4.jpg'},
    {id:5, img:'./images/car5.jpg'},
    {id:6, img:'./images/car6.jpg'},
]