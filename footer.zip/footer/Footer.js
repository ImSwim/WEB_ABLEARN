import React from 'react';
import './footer.css'

const Footer = () => {
    return (
        <footer id="footer">
            <div className="inner">
                <h2><img src="./images/logo.png" alt="탐라는전기차" /></h2>
                <p className="bottom-menu">
                    <a href="#">탐라는 전기차</a>
                    <a href="#">전기차 충전소 위치</a>
                    <a href="#">JEJU 전기차 관련 소식</a>
                    <a href="#">이용약관</a>
                    <a href="#">개인정보처리방침</a>
                </p>
                <p>COPYRIGHT ⓒ All rights RESERVED.</p>
            </div>
        </footer>
    );
};

export default Footer;