import React from 'react';
import './header.css'
// import { AiOutlineMenu } from "react-icons/ai";
 

const Header = () => {
    return (
        <div id="header">
            <div className="inner">
                <h1><img src="./images/logo_b.png" alt="탐라는 전기차" /></h1>
                <p className="all-menu">
                    <i>
                        ‘  
                    </i>
                </p>
            </div>
        </div>
    );
};

export default Header;